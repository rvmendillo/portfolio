# MindHarbor — native iOS mental-wellness tracker

MindHarbor is a privacy-first SwiftUI prototype for quick day-to-day self-reflection. It is intentionally a wellness tool, not a diagnostic or emergency-care product.

## Current build

- Native SwiftUI UI, iOS 17+
- SwiftData local persistence
- Daily mood, energy, stress, sleep, activity, tags, and notes
- Native Swift Charts for 7/14/30-day mood and energy trends
- 7-day averages
- Check-in streak
- Mood stability score (transparent app-derived metric; not clinical)
- Energy trend using ordinary least-squares slope over time
- Mood/energy Pearson correlation when enough data exists
- Personal sleep/activity associations with minimum sample gating and non-causal wording
- Local-data deletion
- No account, ads, external analytics, cloud sync, or AI dependency

## Mood stability formula

First average multiple check-ins within each calendar day. For consecutive daily mood averages on a 1...5 scale:

`mean_change = mean(abs(daily_mood[t] - daily_mood[t-1]))`

`stability = clamp(100 * (1 - mean_change / 4), 0, 100)`

Interpretation is deliberately limited: higher means the user's recorded mood changed less between consecutive check-ins. It is **not** a validated clinical score and should not be used to infer a diagnosis.

## Evidence design notes

1. Repeated in-the-moment / longitudinal self-report is useful for observing within-person affective dynamics. Emotion-dynamics research distinguishes average affect from variability/instability over time.
2. WHO-5 is a validated five-item well-being instrument over the prior two weeks. WHO's official scoring sums five 0...5 responses (0...25) and multiplies by four for a 0...100 percentage score. This prototype does **not** reproduce the questionnaire text. Before shipping a WHO-5 screen, review the current WHO license/attribution requirements and implement the official instrument verbatim.
3. Exercise has evidence for reducing depressive symptoms in randomized-trial syntheses. The app therefore offers activity as a gentle option, not a guarantee or substitute for treatment.
4. All personal associations are phrased as associations, not causes.

Reference starting points:
- WHO. The World Health Organization-Five Well-Being Index (WHO-5), 2024.
- Houben M, Van Den Noortgate W, Kuppens P. The relation between short-term emotion dynamics and psychological well-being: a meta-analysis. Psychological Bulletin. 2015.
- Ebner-Priemer UW, Trull TJ. Analytic strategies for understanding affective (in)stability and other dynamic processes in psychopathology. Journal of Abnormal Psychology. 2009.
- Noetel M, et al. Effect of exercise for depression: systematic review and network meta-analysis of randomized controlled trials. BMJ. 2024;384:e075847.

## Build

Open `MindHarbor.xcodeproj` in Xcode 15+ on macOS, select an iOS 17+ simulator or device, choose your Development Team if installing on a physical device, then Run.

## Next implementation tranche

- Daily notification scheduling (opt-in)
- Apple HealthKit sleep/activity import (opt-in, read-only)
- Calendar heatmap and weekly summaries
- Export/import JSON or CSV
- Optional WHO-5 module after license/product-mode review
- App-lock / biometric privacy option
- Accessibility polish and localization
- Unit tests for analytics edge cases
- On-device rule-based insight explanation before considering any LLM feature
