import Foundation
import SwiftData

@Model
final class CheckIn {
    var createdAt: Date
    var mood: Int
    var energy: Int
    var stress: Int
    var sleepHours: Double
    var activityMinutes: Int
    var note: String
    var tagsCSV: String

    init(
        createdAt: Date = .now,
        mood: Int,
        energy: Int,
        stress: Int,
        sleepHours: Double,
        activityMinutes: Int,
        note: String = "",
        tags: [String] = []
    ) {
        self.createdAt = createdAt
        self.mood = mood
        self.energy = energy
        self.stress = stress
        self.sleepHours = sleepHours
        self.activityMinutes = activityMinutes
        self.note = note
        self.tagsCSV = tags.joined(separator: ",")
    }

    var tags: [String] {
        tagsCSV.split(separator: ",").map(String.init).filter { !$0.isEmpty }
    }
}
