import Foundation

struct WellnessSnapshot {
    let moodAverage: Double?
    let energyAverage: Double?
    let stressAverage: Double?
    let moodStability: Double?
    let energyTrendPerDay: Double?
    let checkInStreak: Int
    let moodEnergyCorrelation: Double?
}

enum AnalyticsEngine {
    static func snapshot(from all: [CheckIn], now: Date = .now) -> WellnessSnapshot {
        let recent = entries(all, withinDays: 7, now: now)
        return WellnessSnapshot(
            moodAverage: average(recent.map { Double($0.mood) }),
            energyAverage: average(recent.map { Double($0.energy) }),
            stressAverage: average(recent.map { Double($0.stress) }),
            moodStability: moodStabilityScore(recent),
            energyTrendPerDay: linearTrend(recent.map { ($0.createdAt, Double($0.energy)) }),
            checkInStreak: streak(all, now: now),
            moodEnergyCorrelation: pearson(recent.map { Double($0.mood) }, recent.map { Double($0.energy) })
        )
    }

    static func entries(_ all: [CheckIn], withinDays days: Int, now: Date = .now) -> [CheckIn] {
        let start = Calendar.current.date(byAdding: .day, value: -max(days - 1, 0), to: Calendar.current.startOfDay(for: now)) ?? now
        return all.filter { $0.createdAt >= start && $0.createdAt <= now }
            .sorted { $0.createdAt < $1.createdAt }
    }

    static func average(_ values: [Double]) -> Double? {
        guard !values.isEmpty else { return nil }
        return values.reduce(0, +) / Double(values.count)
    }

    // App-derived wellness metric, not a clinical scale.
    // Multiple check-ins on the same calendar day are first averaged, so the score
    // reflects day-to-day change rather than the user's check-in frequency.
    // 100 = no day-to-day mood change; 0 = average jump spans the full 1...5 range.
    static func moodStabilityScore(_ entries: [CheckIn]) -> Double? {
        let calendar = Calendar.current
        let grouped = Dictionary(grouping: entries) { calendar.startOfDay(for: $0.createdAt) }
        let daily = grouped.compactMap { day, items -> (Date, Double)? in
            guard let mean = average(items.map { Double($0.mood) }) else { return nil }
            return (day, mean)
        }.sorted { $0.0 < $1.0 }

        let values = daily.map { $0.1 }
        guard values.count >= 2 else { return nil }
        let changes = zip(values.dropFirst(), values).map { abs($0 - $1) }
        let meanChange = changes.reduce(0, +) / Double(changes.count)
        return max(0, min(100, (1 - meanChange / 4.0) * 100))
    }

    static func linearTrend(_ points: [(Date, Double)]) -> Double? {
        guard points.count >= 3 else { return nil }
        let sorted = points.sorted { $0.0 < $1.0 }
        let origin = sorted[0].0
        let x = sorted.map { $0.0.timeIntervalSince(origin) / 86_400 }
        let y = sorted.map { $0.1 }
        guard let xMean = average(x), let yMean = average(y) else { return nil }
        let numerator = zip(x, y).reduce(0.0) { $0 + ($1.0 - xMean) * ($1.1 - yMean) }
        let denominator = x.reduce(0.0) { $0 + pow($1 - xMean, 2) }
        guard denominator > 0 else { return nil }
        return numerator / denominator
    }

    static func pearson(_ x: [Double], _ y: [Double]) -> Double? {
        guard x.count == y.count, x.count >= 4,
              let mx = average(x), let my = average(y) else { return nil }
        let numerator = zip(x, y).reduce(0.0) { $0 + ($1.0 - mx) * ($1.1 - my) }
        let sx = sqrt(x.reduce(0.0) { $0 + pow($1 - mx, 2) })
        let sy = sqrt(y.reduce(0.0) { $0 + pow($1 - my, 2) })
        guard sx > 0, sy > 0 else { return nil }
        return numerator / (sx * sy)
    }

    static func streak(_ all: [CheckIn], now: Date = .now) -> Int {
        let calendar = Calendar.current
        let days = Set(all.map { calendar.startOfDay(for: $0.createdAt) })
        var cursor = calendar.startOfDay(for: now)
        if !days.contains(cursor), let yesterday = calendar.date(byAdding: .day, value: -1, to: cursor) {
            cursor = yesterday
        }
        var count = 0
        while days.contains(cursor) {
            count += 1
            guard let previous = calendar.date(byAdding: .day, value: -1, to: cursor) else { break }
            cursor = previous
        }
        return count
    }

    static func sleepAssociation(_ all: [CheckIn]) -> String? {
        let recent = entries(all, withinDays: 30)
        let enoughSleep = recent.filter { $0.sleepHours >= 7 }
        let lessSleep = recent.filter { $0.sleepHours < 7 }
        guard enoughSleep.count >= 3, lessSleep.count >= 3,
              let a = average(enoughSleep.map { Double($0.mood) }),
              let b = average(lessSleep.map { Double($0.mood) }) else { return nil }
        let delta = a - b
        guard abs(delta) >= 0.15 else { return "Your mood has been similar across your recorded sleep ranges this month." }
        let direction = delta > 0 ? "higher" : "lower"
        return String(format: "Your recorded mood averaged %.1f points %@ on days after 7+ hours of sleep. This is an association, not proof that sleep caused the change.", abs(delta), direction)
    }

    static func activityAssociation(_ all: [CheckIn]) -> String? {
        let recent = entries(all, withinDays: 30)
        let active = recent.filter { $0.activityMinutes >= 20 }
        let inactive = recent.filter { $0.activityMinutes < 20 }
        guard active.count >= 3, inactive.count >= 3,
              let a = average(active.map { Double($0.mood) }),
              let b = average(inactive.map { Double($0.mood) }) else { return nil }
        let delta = a - b
        guard abs(delta) >= 0.15 else { return "Your mood has been similar on more-active and less-active recorded days this month." }
        let direction = delta > 0 ? "higher" : "lower"
        return String(format: "Your recorded mood averaged %.1f points %@ on days with 20+ activity minutes. This is an association, not proof of cause.", abs(delta), direction)
    }
}
