import SwiftUI
import SwiftData

struct SettingsView: View {
    @Environment(\.modelContext) private var modelContext
    @Query private var checkIns: [CheckIn]
    @State private var showDelete = false

    var body: some View {
        List {
            Section("Privacy") {
                Label("Check-ins are stored locally with SwiftData in this build.", systemImage: "lock.fill")
                Label("No account, ads, analytics SDK, or cloud sync is included.", systemImage: "hand.raised.fill")
            }

            Section("Safety") {
                VStack(alignment: .leading, spacing: 6) {
                    Text("Not emergency care").font(.headline)
                    Text("MindHarbor does not diagnose, treat, or monitor emergencies. If you may be in immediate danger, contact local emergency services or a trusted person nearby.")
                        .font(.subheadline)
                        .foregroundStyle(.secondary)
                }
            }

            Section("About the metrics") {
                VStack(alignment: .leading, spacing: 6) {
                    Text("Mood stability").font(.headline)
                    Text("An app-derived 0–100 score based on the average absolute change between consecutive 1–5 mood ratings. It is intentionally labeled non-clinical.")
                        .font(.subheadline).foregroundStyle(.secondary)
                }
                VStack(alignment: .leading, spacing: 6) {
                    Text("Evidence-backed, not evidence-overstated").font(.headline)
                    Text("The app uses repeated self-report, transparent descriptive statistics, and conservative wording. Validated screening tools should be added only with their exact scoring, attribution, licensing, and referral guidance.")
                        .font(.subheadline).foregroundStyle(.secondary)
                }
            }

            Section("Data") {
                LabeledContent("Check-ins", value: "\(checkIns.count)")
                Button("Delete all local data", role: .destructive) { showDelete = true }
            }

            Section("Version") {
                LabeledContent("Prototype", value: "0.1")
                Text("Built for iOS 17+ with SwiftUI, SwiftData, and Charts.")
                    .font(.footnote).foregroundStyle(.secondary)
            }
        }
        .navigationTitle("More")
        .confirmationDialog("Delete all check-ins?", isPresented: $showDelete, titleVisibility: .visible) {
            Button("Delete all", role: .destructive) {
                try? modelContext.delete(model: CheckIn.self)
                try? modelContext.save()
            }
            Button("Cancel", role: .cancel) { }
        } message: {
            Text("This cannot be undone in the current local-only build.")
        }
    }
}
