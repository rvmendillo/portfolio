import SwiftUI
import SwiftData
import Charts

struct TrendsView: View {
    @Query(sort: \CheckIn.createdAt) private var checkIns: [CheckIn]
    @State private var rangeDays = 14

    private var visible: [CheckIn] { AnalyticsEngine.entries(checkIns, withinDays: rangeDays) }
    private var snapshot: WellnessSnapshot { AnalyticsEngine.snapshot(from: checkIns) }

    var body: some View {
        ScrollView {
            VStack(spacing: 16) {
                Picker("Range", selection: $rangeDays) {
                    Text("7D").tag(7)
                    Text("14D").tag(14)
                    Text("30D").tag(30)
                }
                .pickerStyle(.segmented)

                if visible.isEmpty {
                    ContentUnavailableView("No trend yet", systemImage: "chart.line.uptrend.xyaxis", description: Text("Add check-ins to build your personal baseline."))
                        .padding(.top, 50)
                } else {
                    Chart(visible) { entry in
                        LineMark(x: .value("Day", entry.createdAt), y: .value("Mood", entry.mood))
                            .foregroundStyle(by: .value("Metric", "Mood"))
                        LineMark(x: .value("Day", entry.createdAt), y: .value("Energy", entry.energy))
                            .foregroundStyle(by: .value("Metric", "Energy"))
                    }
                    .chartYScale(domain: 1...5)
                    .frame(height: 250)
                    .padding()
                    .background(.thinMaterial, in: RoundedRectangle(cornerRadius: 20))

                    LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())], spacing: 12) {
                        MetricCard(title: "Mood", value: format(snapshot.moodAverage), subtitle: "7-day average", systemImage: "face.smiling")
                        MetricCard(title: "Energy", value: format(snapshot.energyAverage), subtitle: "7-day average", systemImage: "bolt.fill")
                        MetricCard(title: "Stability", value: snapshot.moodStability.map { "\(Int($0.rounded()))" } ?? "—", subtitle: "0–100 app metric", systemImage: "waveform.path.ecg")
                        MetricCard(title: "Streak", value: "\(snapshot.checkInStreak)", subtitle: "consecutive days", systemImage: "flame.fill")
                    }
                }
            }
            .padding()
        }
        .navigationTitle("Trends")
    }

    private func format(_ value: Double?) -> String {
        value.map { String(format: "%.1f", $0) } ?? "—"
    }
}
