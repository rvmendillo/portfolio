import SwiftUI
import SwiftData

struct TodayView: View {
    @Environment(\.modelContext) private var modelContext
    @Query(sort: \CheckIn.createdAt, order: .reverse) private var checkIns: [CheckIn]

    @State private var mood = 3
    @State private var energy = 3
    @State private var stress = 3
    @State private var sleepHours = 7.0
    @State private var activityMinutes = 20
    @State private var note = ""
    @State private var selectedTags: Set<String> = []
    @State private var saved = false

    private let tags = ["Work", "Social", "Exercise", "Outdoors", "Rest", "Family"]

    private var hasTodayEntry: Bool {
        checkIns.contains { Calendar.current.isDateInToday($0.createdAt) }
    }

    var body: some View {
        Form {
            Section {
                VStack(alignment: .leading, spacing: 6) {
                    Text("How are you doing?")
                        .font(.largeTitle.bold())
                    Text("A short check-in is enough. Track patterns, not perfection.")
                        .foregroundStyle(.secondary)
                }
                .padding(.vertical, 8)
            }

            Section("Core check-in") {
                ScalePicker(title: "Mood", value: $mood, lowLabel: "Very low", highLabel: "Very good")
                ScalePicker(title: "Energy", value: $energy, lowLabel: "Drained", highLabel: "Energized")
                ScalePicker(title: "Stress", value: $stress, lowLabel: "Low", highLabel: "High")
            }

            Section("Context") {
                Stepper(value: $sleepHours, in: 0...14, step: 0.5) {
                    LabeledContent("Sleep") { Text("\(sleepHours, specifier: "%.1f") h") }
                }
                Stepper(value: $activityMinutes, in: 0...300, step: 5) {
                    LabeledContent("Activity") { Text("\(activityMinutes) min") }
                }
                ScrollView(.horizontal, showsIndicators: false) {
                    HStack {
                        ForEach(tags, id: \.self) { tag in
                            Button {
                                if selectedTags.contains(tag) { selectedTags.remove(tag) }
                                else { selectedTags.insert(tag) }
                            } label: {
                                Text(tag)
                                    .padding(.horizontal, 12)
                                    .padding(.vertical, 7)
                                    .background(selectedTags.contains(tag) ? Color.accentColor.opacity(0.18) : Color.secondary.opacity(0.10))
                                    .clipShape(Capsule())
                            }
                            .buttonStyle(.plain)
                        }
                    }
                }
                TextField("Optional note", text: $note, axis: .vertical)
                    .lineLimit(2...5)
            }

            Section {
                Button {
                    save()
                } label: {
                    Label(hasTodayEntry ? "Save another check-in" : "Save check-in", systemImage: "checkmark.circle.fill")
                        .frame(maxWidth: .infinity)
                }
                .buttonStyle(.borderedProminent)
            } footer: {
                Text("MindHarbor is a self-reflection tool, not a diagnosis or replacement for professional care.")
            }
        }
        .navigationTitle("Today")
        .alert("Saved", isPresented: $saved) {
            Button("OK", role: .cancel) { }
        } message: {
            Text("Your check-in was saved on this device.")
        }
    }

    private func save() {
        let entry = CheckIn(
            mood: mood,
            energy: energy,
            stress: stress,
            sleepHours: sleepHours,
            activityMinutes: activityMinutes,
            note: note.trimmingCharacters(in: .whitespacesAndNewlines),
            tags: Array(selectedTags).sorted()
        )
        modelContext.insert(entry)
        try? modelContext.save()
        note = ""
        selectedTags.removeAll()
        saved = true
    }
}
