import SwiftUI

struct RootTabView: View {
    var body: some View {
        TabView {
            NavigationStack { TodayView() }
                .tabItem { Label("Today", systemImage: "sun.max.fill") }
            NavigationStack { TrendsView() }
                .tabItem { Label("Trends", systemImage: "chart.xyaxis.line") }
            NavigationStack { InsightsView() }
                .tabItem { Label("Insights", systemImage: "sparkles") }
            NavigationStack { SettingsView() }
                .tabItem { Label("More", systemImage: "ellipsis.circle") }
        }
    }
}
