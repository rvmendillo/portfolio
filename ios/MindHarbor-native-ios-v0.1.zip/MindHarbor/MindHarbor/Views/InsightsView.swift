import SwiftUI
import SwiftData

struct InsightsView: View {
    @Query(sort: \CheckIn.createdAt) private var checkIns: [CheckIn]

    private var snapshot: WellnessSnapshot { AnalyticsEngine.snapshot(from: checkIns) }

    var body: some View {
        List {
            Section {
                Text("Insights appear only when there is enough of your own data. They summarize patterns and do not diagnose conditions or prove cause and effect.")
                    .foregroundStyle(.secondary)
            }

            Section("Your patterns") {
                if let sleep = AnalyticsEngine.sleepAssociation(checkIns) {
                    InsightRow(icon: "bed.double.fill", title: "Sleep & mood", bodyText: sleep)
                }
                if let activity = AnalyticsEngine.activityAssociation(checkIns) {
                    InsightRow(icon: "figure.walk", title: "Activity & mood", bodyText: activity)
                }
                if let r = snapshot.moodEnergyCorrelation {
                    InsightRow(
                        icon: "link",
                        title: "Mood & energy",
                        bodyText: correlationText(r)
                    )
                }
                if AnalyticsEngine.sleepAssociation(checkIns) == nil,
                   AnalyticsEngine.activityAssociation(checkIns) == nil,
                   snapshot.moodEnergyCorrelation == nil {
                    ContentUnavailableView("Keep checking in", systemImage: "sparkles", description: Text("A few more varied days will make personal insights more meaningful."))
                }
            }

            Section("Gentle actions") {
                ActionRow(icon: "figure.walk", title: "Move a little", detail: "A brief walk or other activity can be a practical wellbeing action. Choose something manageable.")
                ActionRow(icon: "person.2.fill", title: "Connect", detail: "Consider contacting someone you trust when support would help.")
                ActionRow(icon: "moon.stars.fill", title: "Protect sleep", detail: "Use your trend data to notice whether sleep and next-day wellbeing move together for you.")
            }
        }
        .navigationTitle("Insights")
    }

    private func correlationText(_ r: Double) -> String {
        let strength: String
        switch abs(r) {
        case 0..<0.3: strength = "weakly"
        case 0.3..<0.6: strength = "moderately"
        default: strength = "strongly"
        }
        let direction = r >= 0 ? "together" : "in opposite directions"
        return "Over your recent check-ins, mood and energy have moved \(strength) \(direction) (r = \(String(format: "%.2f", r))). Correlation is descriptive, not causal."
    }
}

private struct InsightRow: View {
    let icon: String
    let title: String
    let bodyText: String

    var body: some View {
        HStack(alignment: .top, spacing: 12) {
            Image(systemName: icon).frame(width: 28).foregroundStyle(.tint)
            VStack(alignment: .leading, spacing: 4) {
                Text(title).font(.headline)
                Text(bodyText).font(.subheadline).foregroundStyle(.secondary)
            }
        }
        .padding(.vertical, 4)
    }
}

private struct ActionRow: View {
    let icon: String
    let title: String
    let detail: String

    var body: some View {
        HStack(alignment: .top, spacing: 12) {
            Image(systemName: icon).frame(width: 28).foregroundStyle(.tint)
            VStack(alignment: .leading, spacing: 4) {
                Text(title).font(.headline)
                Text(detail).font(.subheadline).foregroundStyle(.secondary)
            }
        }
        .padding(.vertical, 4)
    }
}
