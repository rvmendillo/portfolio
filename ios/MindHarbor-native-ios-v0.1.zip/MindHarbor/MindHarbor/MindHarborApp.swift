import SwiftUI
import SwiftData

@main
struct MindHarborApp: App {
    var body: some Scene {
        WindowGroup {
            RootTabView()
        }
        .modelContainer(for: CheckIn.self)
    }
}
